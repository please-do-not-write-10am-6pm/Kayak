import Content from '../../components/content';

export default function AnalyticsPage() {
  return <Content title="Analytics" />;
}
