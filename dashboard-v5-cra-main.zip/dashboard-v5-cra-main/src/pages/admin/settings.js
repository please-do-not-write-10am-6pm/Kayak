import Content from '../../components/content';

export default function SettingsPage() {
  return <Content title="Settings" />;
}
