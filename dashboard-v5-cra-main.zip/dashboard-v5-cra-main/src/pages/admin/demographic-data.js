import Content from '../../components/content';

export default function DemographicDataPage() {
  return <Content title="Demographic Data" />;
}
