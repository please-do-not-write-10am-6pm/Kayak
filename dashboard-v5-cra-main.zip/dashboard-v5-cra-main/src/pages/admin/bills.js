import Content from '../../components/content';

export default function BillsPage() {
  return <Content title="Bills" />;
}
