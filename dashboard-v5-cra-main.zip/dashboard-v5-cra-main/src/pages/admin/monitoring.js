import Content from '../../components/content';

export default function MonitoringPage() {
  return <Content title="Monitoring" />;
}
