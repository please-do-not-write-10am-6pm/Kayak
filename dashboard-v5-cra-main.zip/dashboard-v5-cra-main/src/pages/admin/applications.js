import Content from '../../components/content';

export default function ApplicationsPage() {
  return <Content title="Applications" />;
}
