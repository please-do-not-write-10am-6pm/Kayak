import Docs from '../../components/docs';

export default function DocsPage() {
  return <Docs />;
}
