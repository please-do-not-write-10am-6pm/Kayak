module.exports = {
  semi: true,
  trailingComma: 'all',
  singleQuote: true,
  tabWidth: 2,
};
